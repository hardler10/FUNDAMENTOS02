import React from 'react';

export default props =>{

    return(
        <div>{props.nome} {props.sobrenome}</div>
    )
}
